
<?php

session_start();


$_SESSION = array();

// destrói a sessão
session_destroy();


exit();
?>

