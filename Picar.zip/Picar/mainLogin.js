document.addEventListener("DOMContentLoaded", function() {
  const form = document.getElementById('login-form');
  const usernameField = document.getElementById('username');
  const passwordField = document.getElementById('password');
  
  form.addEventListener('submit', function(event) {
    event.preventDefault();
    
    if (usernameField.value === '') {
      alert('Por favor, preencha o campo de nome de utilizador.');
      return;
    }
    
    if (passwordField.value === '') {
      alert('Por favor, preencha o campo de senha.');
      return;
    }
    
    const url = this.action;
    const formData = new FormData(this);
    
    fetch(url, {
      method: 'POST',
      body: formData
    })
    .then(response => {
      if (response.ok) {
        console.log('Dados do formulário enviados com sucesso!');
        // Faça alguma ação aqui, como exibir uma mensagem de sucesso
      } else {
        console.error('Erro ao enviar dados do formulário');
      }
    })
    .catch(error => console.error(error))
    .finally(() => {
      window.location.href = "Picarform.php";
    });
  });
});
